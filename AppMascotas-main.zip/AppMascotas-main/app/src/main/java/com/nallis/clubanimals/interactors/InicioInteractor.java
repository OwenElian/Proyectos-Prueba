package com.nallis.clubanimals.interactors;

public class InicioInteractor {
}
