package com.nallis.clubanimals.interfaces;

public interface InicoInterface {
}
