package com.nallis.clubanimals.interfaces;

public interface RegistroInterface {
    interface View{}
}
