package com.nallis.clubanimals.views;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.nallis.clubanimals.R;

public class MenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
    }
}